<?php

class ezSQLcore_YOURLS extends ezSQLcore {

	var $debug_log = array();
	
}

